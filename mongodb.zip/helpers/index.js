exports.welcomEmail = require("./welcomeEmail");
exports.reset = require("./reset");
exports.parsing = require("./parsing");
